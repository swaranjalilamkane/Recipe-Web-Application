let recipes = [];
let ratings = {}; // { recipeId: { userId: stars, ... } }

export default class RecipesDAO {
  static async injectDB(conn) {
    // No DB needed, initialize in-memory arrays
    if (recipes.length === 0) {
      recipes = [
        {
          _id: "1",
          title: "Tomato Soup",
          ingredients: ["tomato", "basil", "garlic"],
          instructions: "Blend and simmer for 20 minutes",
          diet: "vegan",
          cuisine: "Italian",
          approved: true,
          createdAt: new Date(),
          imageURL: "https://example.com/tomato-soup.jpg",
          user_id: "1",
          ratings: {},
          averageRating: 0,
          totalRatings: 0
        }
        // Add more sample recipes if needed
      ];
    }
  }

  static async getAllRecipes() {
    // Return all recipes (filter approved if needed)
    return recipes.map(r => ({ ...r }));
  }

  static async searchRecipes(query = {}, { page = 0, recipesPerPage = 12 } = {}) {
    let filtered = recipes.filter(r => r.approved);

    if (query.ingredients) {
      filtered = filtered.filter(r =>
        r.ingredients.some(i => query.ingredients.includes(i))
      );
    }
    if (query.diet) filtered = filtered.filter(r => r.diet === query.diet);
    if (query.cuisine) filtered = filtered.filter(r => r.cuisine === query.cuisine);

    const totalNumRecipes = filtered.length;
    const recipesList = filtered.slice(page * recipesPerPage, (page + 1) * recipesPerPage);

    return { recipesList, totalNumRecipes };
  }

  static async getRecipeById(id) {
    const recipe = recipes.find(r => r._id === id);
    if (!recipe) return { error: "Recipe not found" };
    return recipe;
  }

  static async addRecipe(recipeData) {
    const newId = (recipes.length + 1).toString();
    const newRecipe = {
      _id: newId,
      ...recipeData,
      createdAt: new Date(),
      ratings: {},
      averageRating: 0,
      totalRatings: 0
    };
    recipes.push(newRecipe);
    return { insertedId: newId, ...newRecipe };
  }

  static async updateRecipe(id, data) {
    const recipe = recipes.find(r => r._id === id);
    if (!recipe) return { modifiedCount: 0, error: "Recipe not found" };

    Object.assign(recipe, data);
    return { modifiedCount: 1 };
  }

  static async deleteRecipe(id) {
    const index = recipes.findIndex(r => r._id === id);
    if (index === -1) return { deletedCount: 0, error: "Recipe not found" };

    recipes.splice(index, 1);
    return { deletedCount: 1 };
  }

  static async submitRating(recipeId, userId, stars) {
    if (!recipes.find(r => r._id === recipeId)) {
      return { error: "Recipe not found" };
    }

    if (!ratings[recipeId]) ratings[recipeId] = {};
    ratings[recipeId][userId] = stars;

    // Update recipe object for average rating
    const ratingValues = Object.values(ratings[recipeId]);
    const recipe = recipes.find(r => r._id === recipeId);
    recipe.averageRating = ratingValues.reduce((a, b) => a + b, 0) / ratingValues.length;
    recipe.totalRatings = ratingValues.length;
    recipe.ratings = { ...ratings[recipeId] };

    return { message: "Rating submitted successfully" };
  }

  static async getRecipeRatingSummary(recipeId) {
    const recipe = recipes.find(r => r._id === recipeId);
    if (!recipe) return { error: "Recipe not found" };

    return {
      averageRating: recipe.averageRating,
      totalRatings: recipe.totalRatings,
      ratings: recipe.ratings
    };
  }
}
