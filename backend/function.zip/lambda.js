import serverless from "serverless-http";
import app from "./server.js";  // your existing Express app
import RecipesDAO from "./dao/RecipesDAO.js";

// Initialize in-memory store once per container
let initialized = false;

export const handler = serverless(async (req, res) => {
  if (!initialized) {
    await RecipesDAO.injectDB(); // initialize in-memory storage
    console.log("RecipesDAO initialized with in-memory store");
    initialized = true;
  }

  console.log("Lambda request received...");
  
  return app(req, res);
});
